module Example.Questionnaire exposing (..)

--

-- import Example.Model exposing (..)

--

-- import Example.MetaTree exposing (..)
import MultiwayTree exposing (..)

import Example.FormBuilder exposing (..)

import Dict exposing (..)
import Set exposing (..)


type alias OptionalInfoRisk =
  { selected : Bool
  , description : String
  , risk : String
  }


type alias SampleData =
  -- Details
  { details_companyName : String
  , details_contactName : String
  , details_emailAddress : String
  , details_date : String -- Date
  , details_title : String
  , details_telephone : String

  -- Services
  , services_selected : Set String
  , services_description : String
  , services_dataTypes : Set String
  , services_compliancePII : Bool
  , services_compliancePHI : Bool
  , services_compliancePCI : Bool

    -- Supporting Documentation
  , documentation_thirdPartyControls : Bool
  , documentation_3rdParty : String

  -- Awareness and Training
  , awareness_reviewed : OptionalInfoRisk
  , awareness_required : OptionalInfoRisk
  , awareness_required_roleTraining : OptionalInfoRisk
  , awareness_required_compliance : OptionalInfoRisk

  -- Personnel Security
  , personnel_background : OptionalInfoRisk
  , personnel_confidentiality : OptionalInfoRisk
  , personnel_disciplinary : OptionalInfoRisk

  -- Audit and Accountability
  , audit_logActivity : OptionalInfoRisk
  , audit_logActivity_dataElements : OptionalInfoRisk
  , audit_logActivity_storageCapacity : OptionalInfoRisk
  , audit_logActivity_periodicallyReviewed : OptionalInfoRisk
  , audit_logActivity_notifiedFailures : OptionalInfoRisk
  , audit_logActivity_tampering : OptionalInfoRisk
  , audit_definedBaselines : OptionalInfoRisk
  , audit_removeUnnecessary  : OptionalInfoRisk
  , audit_elevatedPrivleges : OptionalInfoRisk
  , audit_softwareRestrictions : OptionalInfoRisk

  -- Access Control
  , accessControl_formalPolicy : OptionalInfoRisk
  , accessControl_formalPolicy_includes : Set String
  , accessControl_leastPrivilege : OptionalInfoRisk
  , accessControl_roleBased : OptionalInfoRisk
  , accessControl_segregateDuties : OptionalInfoRisk
  , accessControl_accountManagement : OptionalInfoRisk
  , accessControl_accountManagement_includes : Set String
  , accessControl_automaticLockout : OptionalInfoRisk
  , accessControl_automaticLock : OptionalInfoRisk
  , accessControl_thirdPartyAccess : OptionalInfoRisk

  -- Identification and Authentication
  , identification_preventDevices : OptionalInfoRisk

  -- Incident Response
  , incidentResponse_regularAssessment : OptionalInfoRisk
  , incidentResponse_formalPolicy : OptionalInfoRisk
  , incidentResponse_formalPlan : OptionalInfoRisk
  , incidentResponse_formalPlan_includes : Set String
  , incidentResponse_formalPlan_testAnnually : OptionalInfoRisk
  , incidentResponse_formalPlan_training : OptionalInfoRisk

  -- System and Communications Protection
  , syscomProtection_internalFirewalls : OptionalInfoRisk
  , syscomProtection_limitedExternalConnections : OptionalInfoRisk
  , syscomProtection_cryptoInTransit : OptionalInfoRisk
  , syscomProtection_cryptoAtRest : OptionalInfoRisk
  , syscomProtection_certificateAuthority : OptionalInfoRisk
  , syscomProtection_terminateSessions : OptionalInfoRisk

  -- System and Information Integrity
  , systemIntegrity_regularlyPatchSystems : OptionalInfoRisk
  , systemIntegrity_antivirus : OptionalInfoRisk
  , systemIntegrity_antivirus_updatedDaily : OptionalInfoRisk
  , systemIntegrity_intrusionDetection : OptionalInfoRisk
  , systemIntegrity_verificationTools : OptionalInfoRisk
  , systemIntegrity_spamProtection : OptionalInfoRisk
  , systemIntegrity_errorMessages : OptionalInfoRisk

  -- Custom Software
  , customSoftware : Bool

  -- System and Service Acquisition
  , acquisition_sdlc : OptionalInfoRisk
  , acquisition_thirdPartySecurity : OptionalInfoRisk
  , acquisition_testNewSoftware : OptionalInfoRisk
  , acquisition_changeControl : OptionalInfoRisk
  , acquisition_changeControl_includes : Set String

  -- Stored Data
  , storeData : Bool
  , storeData_location : Set String

  -- Physical and Environmental Protection
  , physical_privateCloudOrDatacenter : OptionalInfoRisk
  , physical_privateCloudOrDatacenter_includes : Set String
  , physical_protectionPolicy : OptionalInfoRisk
  , physical_securityVideo : OptionalInfoRisk
  , physical_securityVideo_kept60Days : OptionalInfoRisk
  , physical_keyCard : OptionalInfoRisk
  , physical_visitors : OptionalInfoRisk
  , physical_visitors_badges : OptionalInfoRisk
  , physical_visitors_videoKept60Days : OptionalInfoRisk
  , physical_visitors_escorted : OptionalInfoRisk
  , physical_visitors_logsFor90Days : OptionalInfoRisk
  , physical_physicalAccess : OptionalInfoRisk
  , physical_physicalAccess_reviewLogs : OptionalInfoRisk
  , physical_physicalAccess_securityGuard : OptionalInfoRisk
  , physical_secureEquipmentTransfer : OptionalInfoRisk
  , physical_withinUSA : OptionalInfoRisk

  -- Media Protection
  , media_markForHandling : OptionalInfoRisk
  , media_physicalProtection : OptionalInfoRisk
  , media_secureTransport : OptionalInfoRisk
  , media_secureDesruction : OptionalInfoRisk

  -- Cloud Storage Options
  , cloud_storeData : OptionalInfoRisk
  , cloud_storeData_complianceReports : String
  , cloud_storeData_datacenterTier : String
  , cloud_withinUSA : OptionalInfoRisk

  -- Security Assessment and Authorization
  , security_regularAssements : OptionalInfoRisk
  , security_regularAssements_remediation : OptionalInfoRisk
  , security_regularPenetration : OptionalInfoRisk
  , security_continuouslyMonitor : OptionalInfoRisk

  -- Contingency Planning
  , contingency_regularBackups : OptionalInfoRisk
  , contingency_regularBackups_testMedia : OptionalInfoRisk
  , contingency_regularBackups_storeOffsite : OptionalInfoRisk
  , contingency_disasterRecovery : OptionalInfoRisk
  , contingency_disasterRecovery_annualExcercise : OptionalInfoRisk
  , contingency_continuityPlan : OptionalInfoRisk
  , contingency_continuityPlan_annualExcercise : OptionalInfoRisk
  }


defaultOptionalInfoRisk : OptionalInfoRisk
defaultOptionalInfoRisk =
  { selected = True
  , description = ""
  , risk = ""
  }


sampleData : SampleData
sampleData =
    -- Details
    { details_companyName = ""
    , details_contactName = ""
    , details_emailAddress = ""
    , details_date = ""
    , details_title = ""
    , details_telephone = ""

    -- Services
    , services_selected = Set.empty --Set.fromList [ "1_saas", "4_other" ]
    , services_description = ""
    , services_dataTypes = Set.empty --Set.fromList [ "2_phi", "4_conf" ]
    , services_compliancePII = False -- should be maybe
    , services_compliancePHI = False
    , services_compliancePCI = False

    -- Supporting Documentation
    , documentation_thirdPartyControls = False
    , documentation_3rdParty = ""

    -- Awareness and Training
    , awareness_reviewed = defaultOptionalInfoRisk
    , awareness_required = defaultOptionalInfoRisk
    , awareness_required_roleTraining = defaultOptionalInfoRisk
    , awareness_required_compliance = defaultOptionalInfoRisk

    -- Personnel Security
    , personnel_background = defaultOptionalInfoRisk
    , personnel_confidentiality = defaultOptionalInfoRisk
    , personnel_disciplinary = defaultOptionalInfoRisk

    -- Audit and Accountability
    , audit_logActivity = defaultOptionalInfoRisk
    , audit_logActivity_dataElements = defaultOptionalInfoRisk
    , audit_logActivity_storageCapacity = defaultOptionalInfoRisk
    , audit_logActivity_periodicallyReviewed = defaultOptionalInfoRisk
    , audit_logActivity_notifiedFailures = defaultOptionalInfoRisk
    , audit_logActivity_tampering = defaultOptionalInfoRisk
    , audit_definedBaselines = defaultOptionalInfoRisk
    , audit_removeUnnecessary  = defaultOptionalInfoRisk
    , audit_elevatedPrivleges = defaultOptionalInfoRisk
    , audit_softwareRestrictions = defaultOptionalInfoRisk

    -- Access Control
    , accessControl_formalPolicy = defaultOptionalInfoRisk
    , accessControl_formalPolicy_includes = Set.empty
    , accessControl_leastPrivilege = defaultOptionalInfoRisk
    , accessControl_roleBased = defaultOptionalInfoRisk
    , accessControl_segregateDuties = defaultOptionalInfoRisk
    , accessControl_accountManagement = defaultOptionalInfoRisk
    , accessControl_accountManagement_includes = Set.empty
    , accessControl_automaticLockout = defaultOptionalInfoRisk
    , accessControl_automaticLock = defaultOptionalInfoRisk
    , accessControl_thirdPartyAccess = defaultOptionalInfoRisk

    -- Identification and Authentication
    , identification_preventDevices = defaultOptionalInfoRisk

    -- Incident Response
    , incidentResponse_regularAssessment = defaultOptionalInfoRisk
    , incidentResponse_formalPolicy = defaultOptionalInfoRisk
    , incidentResponse_formalPlan = defaultOptionalInfoRisk
    , incidentResponse_formalPlan_includes = Set.empty
    , incidentResponse_formalPlan_testAnnually = defaultOptionalInfoRisk
    , incidentResponse_formalPlan_training = defaultOptionalInfoRisk

    -- System and Communications Protection
    , syscomProtection_internalFirewalls = defaultOptionalInfoRisk
    , syscomProtection_limitedExternalConnections = defaultOptionalInfoRisk
    , syscomProtection_cryptoInTransit = defaultOptionalInfoRisk
    , syscomProtection_cryptoAtRest = defaultOptionalInfoRisk
    , syscomProtection_certificateAuthority = defaultOptionalInfoRisk
    , syscomProtection_terminateSessions = defaultOptionalInfoRisk

    -- System and Information Integrity
    , systemIntegrity_regularlyPatchSystems = defaultOptionalInfoRisk
    , systemIntegrity_antivirus = defaultOptionalInfoRisk
    , systemIntegrity_antivirus_updatedDaily = defaultOptionalInfoRisk
    , systemIntegrity_intrusionDetection = defaultOptionalInfoRisk
    , systemIntegrity_verificationTools = defaultOptionalInfoRisk
    , systemIntegrity_spamProtection = defaultOptionalInfoRisk
    , systemIntegrity_errorMessages = defaultOptionalInfoRisk

    -- Custom Software
    , customSoftware = False

    -- System and Service Acquisition
    , acquisition_sdlc = defaultOptionalInfoRisk
    , acquisition_thirdPartySecurity = defaultOptionalInfoRisk
    , acquisition_testNewSoftware = defaultOptionalInfoRisk
    , acquisition_changeControl = defaultOptionalInfoRisk
    , acquisition_changeControl_includes = Set.empty

    -- Stored Data
    , storeData = False
    , storeData_location = Set.empty

    -- Physical and Environmental Protection
    , physical_privateCloudOrDatacenter = defaultOptionalInfoRisk
    , physical_privateCloudOrDatacenter_includes = Set.empty
    , physical_protectionPolicy = defaultOptionalInfoRisk
    , physical_securityVideo = defaultOptionalInfoRisk
    , physical_securityVideo_kept60Days = defaultOptionalInfoRisk
    , physical_keyCard = defaultOptionalInfoRisk
    , physical_visitors = defaultOptionalInfoRisk
    , physical_visitors_badges = defaultOptionalInfoRisk
    , physical_visitors_videoKept60Days = defaultOptionalInfoRisk
    , physical_visitors_escorted = defaultOptionalInfoRisk
    , physical_visitors_logsFor90Days = defaultOptionalInfoRisk
    , physical_physicalAccess = defaultOptionalInfoRisk
    , physical_physicalAccess_reviewLogs = defaultOptionalInfoRisk
    , physical_physicalAccess_securityGuard = defaultOptionalInfoRisk
    , physical_secureEquipmentTransfer = defaultOptionalInfoRisk
    , physical_withinUSA = defaultOptionalInfoRisk

    -- Media Protection
    , media_markForHandling = defaultOptionalInfoRisk
    , media_physicalProtection = defaultOptionalInfoRisk
    , media_secureTransport = defaultOptionalInfoRisk
    , media_secureDesruction = defaultOptionalInfoRisk

    -- Cloud Storage Options
    , cloud_storeData = defaultOptionalInfoRisk
    , cloud_storeData_complianceReports = ""
    , cloud_storeData_datacenterTier = ""
    , cloud_withinUSA = defaultOptionalInfoRisk

    -- Security Assessment and Authorization
    , security_regularAssements = defaultOptionalInfoRisk
    , security_regularAssements_remediation = defaultOptionalInfoRisk
    , security_regularPenetration = defaultOptionalInfoRisk
    , security_continuouslyMonitor = defaultOptionalInfoRisk

    -- Contingency Planning
    , contingency_regularBackups = defaultOptionalInfoRisk
    , contingency_regularBackups_testMedia = defaultOptionalInfoRisk
    , contingency_regularBackups_storeOffsite = defaultOptionalInfoRisk
    , contingency_disasterRecovery = defaultOptionalInfoRisk
    , contingency_disasterRecovery_annualExcercise = defaultOptionalInfoRisk
    , contingency_continuityPlan = defaultOptionalInfoRisk
    , contingency_continuityPlan_annualExcercise = defaultOptionalInfoRisk
    }


questionnaire : Branches SampleData --Tree (SectionKinds SampleData) 
questionnaire =
  Header
    { id = "infosec-questionnaire"
    , imgSrc = ""
    , title = "Information Security Questionnaire"
    }
    [ contractorInformation
    , definitions
    , serviceDescription
    , supportingDocumentation
    , awarenessAndTraining
    , personnelSecurity
    , audit
    , accessControl
    , identification
    , incidentResponse
    , syscomProtection
    , systemIntegrity
    , customSoftware
    , acquisition
    , media
    , security
    , contingency
    , storeData
    , physical
    , cloud

    
    ]


contractorInformation : SectionKinds SampleData
contractorInformation =
  Branch <| Grid
    { title = "Contractor Information"
    }
    [ Leaf <| InputField
      { id = "companyName"
      , label = "Company Name:"
      , placeholder = ""
      , error = False
      , get = .details_companyName
      , set = (\ model data -> { model | details_companyName = data } )
      }
    , Leaf <| InputField
      { id = "contactName"
      , label = "Contact Name:"
      , placeholder = ""
      , error = False
      , get = .details_contactName
      , set = (\ model data -> { model | details_contactName = data } )
      }
    , Leaf <| InputField
      { id = "emailAddress"
      , label = "Email Address:"
      , placeholder = "user@email.com"
      , error = False
      , get = .details_emailAddress
      , set = (\ model data -> { model | details_emailAddress = data } )
      }
    , Leaf <| InputField
      { id = "date"
      , label = "Date:"
      , placeholder = "mm-dd-yyyy"
      , error = False
      , get = .details_date
      , set = (\ model data -> { model | details_date = data } )
      }
    , Leaf <| InputField
      { id = "title"
      , label = "Title:"
      , placeholder = ""
      , error = False
      , get = .details_title
      , set = (\ model data -> { model | details_title = data } )
      }
    , Leaf <| InputField
      { id = "telephone"
      , label = "Telephone:"
      , placeholder = "(xxx) xxx-xxxx"
      , error = False
      , get = .details_telephone
      , set = (\ model data -> { model | details_telephone = data } )
      }
    ]


definitions : SectionKinds SampleData
definitions =
  Branch <| List
    { title = "Definitions:"
    }
    [ Leaf <| LabeledTextField
      { id = "information_system"
      , label = "Information System"
      , text = "Those information systems used by Contractor to collect, process, maintain, use, share, disseminate, or disposition VSP data."
      }
    , Leaf <| LabeledTextField
      { id = "vsp_data"
      , label = "VSP Data"
      , text = "Information provided to Contractor by or at the direction of VSP that: (i) identi es an individual (including, without limitation, names, signatures, addresses, telephone numbers, e-mail addresses and other unique identi ers); or (ii) can be used to authenticate an individual (including, without limitation, employee identi cation numbers, government- issued identi cation numbers, passwords or PINs, biometric or health data, answers to security questions and other personal identi ers)."
      }
    ]


serviceDescription : SectionKinds SampleData
serviceDescription =
  Branch <| Bullets
    { title = "Service Description:"
    , type_ = AlphaBullet
    , show = False
    }
    [ Branch <| Bullets
      { title = "Check all boxes which best describe the service(s) you will be offering VSP."
      , type_ = NumericBullet
      , show = True
      }
      [ Leaf <| RadioField
        { id = "service_selected"
        , options = Dict.fromList
          [ ( "1_saas", "SaaS" )
          , ( "2_iaas", "IaaS" )
          , ( "3_talent", "Talent/Labor" )
          , ( "4_other", "Other" )
          ]
        , get = .services_selected
        , set = (\ model data -> { model | services_selected = data } )
        }
      , Leaf <| InputField
        { id = "services_description"
        , label = "Please describe services offered"
        , placeholder = ""
        , error = False
        , get = .services_description
        , set = (\ model data -> { model | services_description = data } )
        }
      ]
    , Branch <| Bullets
      { title = "Check all boxes which describe the type of data you will be handling on behalf of VSP."
      , type_ = NumericBullet
      , show = True
      }
      [ Leaf <| RadioField
        { id = "services_dataTypes"
        , options = Dict.fromList
          [ ( "1_pii", "PII" )
          , ( "2_phi", "PHI" )
          , ( "3_pci", "PCI" )
          , ( "4_conf", "Business Confidential" )
          ]
        , get = .services_dataTypes
        , set = (\ model data -> { model | services_dataTypes = data } )
        }
      , Branch <| Bullets
        { title = "Does your organization comply with Massachusetts 201 CMR 17.00?"
        , type_ = NumericBullet
        , show = True
        }
        [ Branch <| Conditional
          { predicate = (\ model -> Set.member "1_pii" model.services_dataTypes )
          , hide = True
          }
          [ Leaf <| BoolField
            { id = "services_compliancePII"
            , get = .services_compliancePII
            , set = (\ model data -> { model | services_compliancePII = data } )
            }
          ]
        ]
        
      , Branch <| Bullets
        { title = "Does your organization comply with the HIPAA & HITECH rules?"
        , type_ = NumericBullet
        , show = True
        }
        [ Branch <| Conditional
          { predicate = (\ model -> Set.member "2_phi" model.services_dataTypes )
          , hide = True
          }
          [ Leaf <| BoolField
            { id = "services_compliancePHI"
            , get = .services_compliancePHI
            , set = (\ model data -> { model | services_compliancePHI = data } )
            }
          ]
        ]
        
      , Branch <| Bullets
        { title = "Does your organization comply with thePayment Card Industry Data Security Standards?"
        , type_ = NumericBullet
        , show = True
        }
        [ Branch <| Conditional
          { predicate = (\ model -> Set.member "3_pci" model.services_dataTypes )
          , hide = True
          }
          [ Leaf <| BoolField
            { id = "services_compliancePCI"
            , get = .services_compliancePCI
            , set = (\ model data -> { model | services_compliancePCI = data } )
            }
          ]
        ]
      ]
    ]


supportingDocumentation : SectionKinds SampleData
supportingDocumentation =
  Branch <| Bullets
    { title = "Supporting Documentation:"
    , type_ = AlphaBullet
    , show = False
    }
    [ Branch <| Bullets
      { title = "Does your organization acquire certi cation from an independent third party validating your information security controls?"
      , type_ = NumericBullet
      , show = True
      }
      [ Leaf <| BoolField
        { id = "documentation_thirdPartyControls"
        , get = .documentation_thirdPartyControls
        , set = (\ model data -> { model | documentation_thirdPartyControls = data } )
        }
      , Leaf <| InputField
        { id = "documentation_3rdParty"
        , label = "Documents:"
        , placeholder = "Documents..."
        , error = False
        , get = .documentation_3rdParty
        , set = (\ model data -> { model | documentation_3rdParty = data } )
        }
      ]
    ]


type alias OptionalInfoRiskModel model =
  { id : String
  , title : String
  , descriptionLabel : String
  , riskLabel : String
  , get : model -> OptionalInfoRisk
  , set : model -> OptionalInfoRisk -> model
  }


optionalInfoRisk : OptionalInfoRiskModel SampleData -> List (SectionKinds SampleData) -> SectionKinds SampleData
optionalInfoRisk model children =
  Branch <| Bullets
    { title = model.title
    , type_ = NumericBullet
    , show = True
    }
    <| List.concat
      [ [ Leaf <| BoolField
            { id = model.id ++ "_selected"
            , get = (\ model_ -> (model.get model_).selected )
            , set =
              (\ model_ data ->
                let
                  innerModel = model.get model_
                in
                  model.set model_ { innerModel | selected = data }
              )
            }
        , Leaf <| InputField
            { id = model.id ++ "_description"
            , label = model.descriptionLabel
            , placeholder = ""
            , error = False
            , get = (\ model_ -> (model.get model_).description )
            , set =
              (\ model_ data ->
                let
                  innerModel = model.get model_
                in
                  model.set model_ { innerModel | description = data }
              )
            }
        , Branch <| Conditional
          { predicate = (\ model_ -> not (model.get model_).selected )
          , hide = True
          }
          [ Leaf <| InputField
            { id = model.id ++ "_risk"
            , label = model.riskLabel
            , placeholder = ""
            , error = True
            , get = (\ model_ -> (model.get model_).risk )
            , set =
              (\ model_ data ->
                let
                  innerModel = model.get model_
                in
                  model.set model_ { innerModel | risk = data }
              )
            }
          ]
        ]
      , children
      ]


awarenessAndTraining : SectionKinds SampleData
awarenessAndTraining =
  Branch <| Bullets
      { title = "AWARENESS AND TRAINING"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
          { id = "awareness_reviewed"
          , title = "Does your organization have a formal security awareness policy that is periodically reviewed, updated, and approved by management?"
          , descriptionLabel = "Provide further detail if necessary"
          , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
          , get = .awareness_reviewed
          , set = (\ model data -> { model | awareness_reviewed = data } )
          } []

      , optionalInfoRisk
        { id = "awareness_required"
        , title = "Does your organization have a security awareness training program that requires annual participation by all personnel?"
        , descriptionLabel = "Describe how your organization provides appropriate information security training to personnel."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .awareness_required
        , set = (\ model data -> { model | awareness_required = data } )
        }

        [ optionalInfoRisk
          { id = "awareness_required_roleTraining"
          , title = "Does your security awareness training program use role-based training?"
          , descriptionLabel = "Provide further detail if necessary"
          , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
          , get = .awareness_required_roleTraining
          , set = (\ model data -> { model | awareness_required_roleTraining = data } )
          } []

        , optionalInfoRisk
          { id = "awareness_required_compliance"
          , title = "Does your organization track security awareness training completion by personnel to ensure compliance?"
          , descriptionLabel = "Provide further detail if necessary"
          , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
          , get = .awareness_required_compliance
          , set = (\ model data -> { model | awareness_required_compliance = data } )
          } []
        ]
      ]


personnelSecurity : SectionKinds SampleData
personnelSecurity =
  Branch <| Bullets
      { title = "PERSONNEL SECURITY"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "personnel_background"
        , title = "Does your organization perform background screening of all personnel/contingent workers prior to employment?"
        , descriptionLabel = "Provide further detail if necessary"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .personnel_background
        , set = (\ model data -> { model | personnel_background = data } )
        } []

      , optionalInfoRisk
        { id = "personnel_confidentiality"
        , title = "Does your organization require personnel/contingent workers to sign con dentiality agreements prior to employment?"
        , descriptionLabel = "Provide further detail if necessary"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .personnel_confidentiality
        , set = (\ model data -> { model | personnel_confidentiality = data } )
        } []

      , optionalInfoRisk
        { id = "personnel_disciplinary"
        , title = "Does your organization have a formal disciplinary policy for violations of information security policies?"
        , descriptionLabel = "Provide further detail if necessary"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .personnel_disciplinary
        , set = (\ model data -> { model | personnel_disciplinary = data } )
        } []
      ]


audit : SectionKinds SampleData
audit =
  Branch <| Bullets
      { title = "AUDIT AND ACCOUNTABILITY"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "audit_logActivity"
        , title = "Does your organization log network and information system activity with suf cient detail to support forensics?"
        , descriptionLabel = "List which events are logged"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .audit_logActivity
        , set = (\ model data -> { model | audit_logActivity = data } )
        }
        [ optionalInfoRisk
            { id = "audit_logActivity_dataElements"
            , title = "Do audit logs include data elements such as type of event, time stamps, source and destination, descriptions, etc.?"
            , descriptionLabel = "Provide further detail if necessary"
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .audit_logActivity_dataElements
            , set = (\ model data -> { model | audit_logActivity_dataElements = data } )
            } []

        , optionalInfoRisk
            { id = "audit_logActivity_storageCapacity"
            , title = "Is suf cient storage capacity allocated to audit logs to meet your record retention requirements?"
            , descriptionLabel = "Provide further detail if necessary"
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .audit_logActivity_storageCapacity
            , set = (\ model data -> { model | audit_logActivity_storageCapacity = data } )
            } []

        , optionalInfoRisk
            { id = "audit_logActivity_periodicallyReviewed"
            , title = "Are audit logs periodically reviewed?"
            , descriptionLabel = "Please provide the frequency of review:"
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .audit_logActivity_periodicallyReviewed
            , set = (\ model data -> { model | audit_logActivity_periodicallyReviewed = data } )
            } []

        , optionalInfoRisk
            { id = "audit_logActivity_notifiedFailures"
            , title = "Are personnel automatically noti ed of audit log failures?"
            , descriptionLabel = "Please provide the frequency of review:"
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .audit_logActivity_notifiedFailures
            , set = (\ model data -> { model | audit_logActivity_notifiedFailures = data } )
            } []

        , optionalInfoRisk
            { id = "audit_logActivity_tampering"
            , title = "Are audit logs protected from tampering or deletion?"
            , descriptionLabel = "Please provide the frequency of review:"
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .audit_logActivity_tampering
            , set = (\ model data -> { model | audit_logActivity_tampering = data } )
            } []
        ]

      , optionalInfoRisk
        { id = "audit_definedBaselines"
        , title = "Does your organization have de ned information system minimum security standards or baselines?"
        , descriptionLabel = "Describe your organization’s minimum security standards or baselines, including whether or not they follow an industry recognized standard."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .audit_definedBaselines
        , set = (\ model data -> { model | audit_definedBaselines = data } )
        } []

      , optionalInfoRisk
        { id = "audit_removeUnnecessary"
        , title = "Does your organization harden information systems by removing unnecessary services?"
        , descriptionLabel = "Describe the steps taken to harden both endpoints and servers in your organization"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .audit_removeUnnecessary
        , set = (\ model data -> { model | audit_removeUnnecessary = data } )
        } []

      , optionalInfoRisk
        { id = "audit_elevatedPrivleges"
        , title = "Does your organization ensure standard users are not granted elevated privileges to perform their work?"
        , descriptionLabel = "Does your organization ensure standard users are not granted elevated privileges to perform their work?"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .audit_elevatedPrivleges
        , set = (\ model data -> { model | audit_elevatedPrivleges = data } )
        } []

      , optionalInfoRisk
        { id = "audit_softwareRestrictions"
        , title = "Does your organization employ software usage and installation restrictions?"
        , descriptionLabel = "Does your organization ensure standard users are not granted elevated privileges to perform their work?"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .audit_softwareRestrictions
        , set = (\ model data -> { model | audit_softwareRestrictions = data } )
        } []
      ]


accessControl : SectionKinds SampleData
accessControl =
  Branch <| Bullets
      { title = "ACCESS CONTROL"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "accessControl_formalPolicy"
        , title = "Does your organization have a formal access control policy that is periodically reviewed, updated, and approved by management?"
        , descriptionLabel = "Describe your organization’s risk assessment and treatment strategy."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .accessControl_formalPolicy
        , set = (\ model data -> { model | accessControl_formalPolicy = data } )
        }
        [ Branch <| Bullets
          { title = "Does your access control policy include (check all that apply):"
          , type_ = NumericBullet
          , show = True
          }
          [ Leaf <| RadioField
            { id = "accessControl_formalPolicy_includes"
            , options = Dict.fromList
              [ ( "1_remote", "Restrictions on remote access?" )
              , ( "2_wirelessNetwork", "Restrictions on wireless network access?" )
              , ( "3_mobileDevice", "Restrictions on mobile device usage on your network?" )
              ]
            , get = .accessControl_formalPolicy_includes
            , set = (\ model data -> { model | accessControl_formalPolicy_includes = data } )
            }
          ]
        ]

      , optionalInfoRisk
        { id = "accessControl_leastPrivilege"
        , title = "Does your organization use the principle of least privilege when authorizing access to information and information systems?"
        , descriptionLabel = "Describe how your information systems will enforce the most restrictive set of privileges needed by users."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .accessControl_leastPrivilege
        , set = (\ model data -> { model | accessControl_leastPrivilege = data } )
        } []

      , optionalInfoRisk
        { id = "accessControl_roleBased"
        , title = "Does your organization authorize access to information and information systems using role-based access control policies?"
        , descriptionLabel = "Provide further detail if necessary"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .accessControl_roleBased
        , set = (\ model data -> { model | accessControl_roleBased = data } )
        } []

      , optionalInfoRisk
        { id = "accessControl_segregateDuties"
        , title = "Does your organization segregate conflicting duties to reduce opportunities for unauthorized or unintentional misuse of information systems?"
        , descriptionLabel = "Describe how your organization’s information systems enforces seperation of duties:"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .accessControl_segregateDuties
        , set = (\ model data -> { model | accessControl_segregateDuties = data } )
        } []

      , optionalInfoRisk
        { id = "accessControl_accountManagement"
        , title = "Does your organization have an account management process to administer system accounts throughout their lifecycle?"
        , descriptionLabel = "Describe your organization’s account management process."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .accessControl_accountManagement
        , set = (\ model data -> { model | accessControl_accountManagement = data } )
        }
        [ Branch <| Bullets
          { title = "Does your account management process include (check all that apply):"
          , type_ = NumericBullet
          , show = True
          }
          [ Leaf <| RadioField
            { id = "accessControl_accountManagement_includes"
            , options = Dict.fromList
              [ ( "1_managerApproval", "Manager approvals to create, modify or delete system accounts?" )
              , ( "2_automatedDisabling", "Automated disabling of inactive system accounts?" )
              , ( "3_restrictSharedAccounts", "Restricted use of shared system accounts?" )
              , ( "4_monitorAtypicalUsage", "Monitoring system accounts for atypical usage?" )
              ]
            , get = .accessControl_accountManagement_includes
            , set = (\ model data -> { model | accessControl_accountManagement_includes = data } )
            }
          ]
        ]

      , optionalInfoRisk
        { id = "accessControl_automaticLockout"
        , title = "Does your organization automatically lockout system accounts after at most  ve unsuccessful logon attempts?"
        , descriptionLabel = "Provide further detail if necessary"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .accessControl_automaticLockout
        , set = (\ model data -> { model | accessControl_automaticLockout = data } )
        } []

      , optionalInfoRisk
        { id = "accessControl_automaticLock"
        , title = "Does your organization automatically lock workstations after at most  fteen minutes of inactivity?"
        , descriptionLabel = "Provide further detail if necessary"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .accessControl_automaticLock
        , set = (\ model data -> { model | accessControl_automaticLock = data } )
        } []

      , optionalInfoRisk
        { id = "accessControl_thirdPartyAccess"
        , title = "Does your organization allow, with prior approval, third party access to your information systems?"
        , descriptionLabel = "Provide further detail if necessary"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .accessControl_thirdPartyAccess
        , set = (\ model data -> { model | accessControl_thirdPartyAccess = data } )
        } []
      ]


identification : SectionKinds SampleData
identification =
  Branch <| Bullets
      { title = "IDENTIFICATION AND AUTHENTICATION"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "identification_preventDevices"
        , title = "Does your organization have a process to prevent unauthorized devices from connecting to your internal network?"
        , descriptionLabel = "Provide further detail if necessary"
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .identification_preventDevices
        , set = (\ model data -> { model | identification_preventDevices = data } )
        } []
      ]


incidentResponse : SectionKinds SampleData
incidentResponse =
  Branch <| Bullets
      { title = "INCIDENT RESPONSE"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "incidentResponse_regularAssessment"
        , title = "Does your organization conduct a regular assessment of risk and its likelihood and magnitude of harm?"
        , descriptionLabel = "Describe your organization’s risk assessment and treatment strategy."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .incidentResponse_regularAssessment
        , set = (\ model data -> { model | incidentResponse_regularAssessment = data } )
        } []

      , optionalInfoRisk
        { id = "incidentResponse_formalPolicy"
        , title = "Does your organization have a formal incident response policy?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .incidentResponse_formalPolicy
        , set = (\ model data -> { model | incidentResponse_formalPolicy = data } )
        } []

      , optionalInfoRisk
        { id = "incidentResponse_formalPlan"
        , title = "Does your organization have a formal Incident Response Plan?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .incidentResponse_formalPlan
        , set = (\ model data -> { model | incidentResponse_formalPlan = data } )
        }
        [ Branch <| Bullets
          { title = "Does your access control policy include (check all that apply):"
          , type_ = NumericBullet
          , show = True
          }
          [ Leaf <| RadioField
            { id = "incidentResponse_formalPlan_includes"
            , options = Dict.fromList
              [ ( "1_identification", "Identification of incidents?" )
              , ( "2_reporting", "Reporting of incidents?" )
              , ( "3_handling", "Handling of incidents?" )
              , ( "4_escalation", "Excalation of incidents?" )
              , ( "5_rootCause", "Root cause analysis?" )
              , ( "6_notification", "Notificaiton of stakeholders?" )
              ]
            , get = .incidentResponse_formalPlan_includes
            , set = (\ model data -> { model | incidentResponse_formalPlan_includes = data } )
            }
          ]

          , optionalInfoRisk
            { id = "incidentResponse_formalPlan_testAnnually"
            , title = "Does your organization test your incident response procedures at least annually?"
            , descriptionLabel = "Provide further detail if necessary."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .incidentResponse_formalPlan_testAnnually
            , set = (\ model data -> { model | incidentResponse_formalPlan_testAnnually = data } )
            } []

          , optionalInfoRisk
            { id = "incidentResponse_formalPlan_training"
            , title = "Does your organization train personnel on incident response procedures?"
            , descriptionLabel = "Provide further detail if necessary."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .incidentResponse_formalPlan_training
            , set = (\ model data -> { model | incidentResponse_formalPlan_training = data } )
            } []
        ]
      ]


syscomProtection : SectionKinds SampleData
syscomProtection =
  Branch <| Bullets
      { title = "SYSTEM AND COMMUNICATIONS PROTECTION"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "syscomProtection_internalFirewalls"
        , title = "Does your organization use  rewalls to segment internal networks?"
        , descriptionLabel = "Describe how your organizations manages  rewalls, including firewall rule change procedures."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .syscomProtection_internalFirewalls
        , set = (\ model data -> { model | syscomProtection_internalFirewalls = data } )
        } []

      , optionalInfoRisk
        { id = "syscomProtection_limitedExternalConnections"
        , title = "Does your organization limit the number of external network connections to the information systems handling VSP data?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .syscomProtection_limitedExternalConnections
        , set = (\ model data -> { model | syscomProtection_limitedExternalConnections = data } )
        } []

      , optionalInfoRisk
        { id = "syscomProtection_cryptoInTransit"
        , title = "Does your organization use cryptographic mechanisms to protect VSP data in-transit?"
        , descriptionLabel = "Describe which cryptographic mechanisms are used to protect VSP data in transit."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .syscomProtection_cryptoInTransit
        , set = (\ model data -> { model | syscomProtection_cryptoInTransit = data } )
        } []

      , optionalInfoRisk
        { id = "syscomProtection_cryptoAtRest"
        , title = "Does your organization use cryptographic mechanisms to protect VSP data at-rest?"
        , descriptionLabel = "Describe which cryptographic mechanisms are used to protect VSP data at rest."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .syscomProtection_cryptoAtRest
        , set = (\ model data -> { model | syscomProtection_cryptoAtRest = data } )
        } []

      , optionalInfoRisk
        { id = "syscomProtection_certificateAuthority"
        , title = "Does your organization obtain public key certi cates from an industry-recognized certi cate authority?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .syscomProtection_certificateAuthority
        , set = (\ model data -> { model | syscomProtection_certificateAuthority = data } )
        } []

      , optionalInfoRisk
        { id = "syscomProtection_terminateSessions"
        , title = "Does your organization terminate user sessions after at least  fteen minutes of inactivity?"
        , descriptionLabel = "Describe how your organization enforces session timeout."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .syscomProtection_terminateSessions
        , set = (\ model data -> { model | syscomProtection_terminateSessions = data } )
        } []
      ]


systemIntegrity : SectionKinds SampleData
systemIntegrity =
  Branch <| Bullets
      { title = "PERSONNEL SECURITY"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "systemIntegrity_regularlyPatchSystems"
        , title = "Does your organization regularly patch information systems, applications, and network devices?"
        , descriptionLabel = "Describe your organization’s patch management policy."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .systemIntegrity_regularlyPatchSystems
        , set = (\ model data -> { model | systemIntegrity_regularlyPatchSystems = data } )
        } []

      , optionalInfoRisk
        { id = "systemIntegrity_antivirus"
        , title = "Does your organization employ industry-recognized antivirus software on all endpoints and servers?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .systemIntegrity_antivirus
        , set = (\ model data -> { model | systemIntegrity_antivirus = data } )
        }
        [ optionalInfoRisk
          { id = "systemIntegrity_antivirus_updatedDaily"
          , title = "Is your antivirus software updated at least daily?"
          , descriptionLabel = "Provide further detail if necessary."
          , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
          , get = .systemIntegrity_antivirus_updatedDaily
          , set = (\ model data -> { model | systemIntegrity_antivirus_updatedDaily = data } )
          } []
        ]

      , optionalInfoRisk
        { id = "systemIntegrity_intrusionDetection"
        , title = "Does your organization employ intrusion detection and prevention mechanisms?"
        , descriptionLabel = "Describe how your organization employs intrusion prevention and detection mechanisms."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .systemIntegrity_intrusionDetection
        , set = (\ model data -> { model | systemIntegrity_intrusionDetection = data } )
        } []

      , optionalInfoRisk
        { id = "systemIntegrity_verificationTools"
        , title = "Does your organization employ automated integrity veri cation tools to detect unauthorized changes to information systems handling VSP data?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .systemIntegrity_verificationTools
        , set = (\ model data -> { model | systemIntegrity_verificationTools = data } )
        } []

      , optionalInfoRisk
        { id = "systemIntegrity_spamProtection"
        , title = "Does your organization employ spam protection mechanisms to detect and stop unsolicited messages?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .systemIntegrity_spamProtection
        , set = (\ model data -> { model | systemIntegrity_spamProtection = data } )
        } []

      , optionalInfoRisk
        { id = "systemIntegrity_errorMessages"
        , title = "Does your organization structure error messages to not include information that could be exploited by adversaries?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .systemIntegrity_errorMessages
        , set = (\ model data -> { model | systemIntegrity_errorMessages = data } )
        } []
      ]


customSoftware : SectionKinds SampleData
customSoftware =
  Branch <| List
    { title = "Does your organization supply custom-built software for deployment on VSP"
    }
    [ Leaf <| BoolField
      { id = "customSoftware"
      , get = .customSoftware
      , set = (\ model data -> { model | customSoftware = data } )
      }
    ]

acquisition : SectionKinds SampleData
acquisition =
  Branch <| Bullets
      { title = "SYSTEM AND SERVICE ACQUISITION"
      , type_ = NumericBullet
      , show = True
      }
      [ Branch <| Conditional
          { predicate = (\ model -> model.customSoftware)
          , hide = True
          }
          [ optionalInfoRisk
            { id = "acquisition_sdlc"
            , title = "Does your organization have a formal system development life cycle that incorporates information security considerations?"
            , descriptionLabel = "Describe how your SDLC incorporates information security considerations."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .acquisition_sdlc
            , set = (\ model data -> { model | acquisition_sdlc = data } )
            } []

          , optionalInfoRisk
            { id = "acquisition_thirdPartySecurity"
            , title = "Does your organization ensure third-party providers employ adequate security measures to protect VSP data?"
            , descriptionLabel = "Describe how your organization ensures third-party providers employ adequate security measures to protect VSP data."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .acquisition_thirdPartySecurity
            , set = (\ model data -> { model | acquisition_thirdPartySecurity = data } )
            } []

          , optionalInfoRisk
            { id = "acquisition_testNewSoftware"
            , title = "Does your organization perform security testing of new software prior to use in production?"
            , descriptionLabel = "Provide further detail if necessary."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .acquisition_testNewSoftware
            , set = (\ model data -> { model | acquisition_testNewSoftware = data } )
            } []

          , optionalInfoRisk
            { id = "acquisition_changeControl"
            , title = "Does your organization have a formal change control policy that is periodically reviewed, updated, and approved by management?"
            , descriptionLabel = "Provide further detail if necessary"
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .acquisition_changeControl
            , set = (\ model data -> { model | acquisition_changeControl = data } )
            }
            [ Branch <| Bullets
              { title = "Does your access control policy include (check all that apply):"
              , type_ = NumericBullet
              , show = True
              }
              [ Leaf <| RadioField
                { id = "acquisition_changeControl_includes"
                , options = Dict.fromList
                  [ ( "1_documentCHanges", "Documenting changes?" )
                  , ( "2_securityReview", "Information security review and approval?" )
                  , ( "3_restrictAccess", "Restrictions on those who have access to make changes to production?" )
                  ]
                , get = .acquisition_changeControl_includes
                , set = (\ model data -> { model | acquisition_changeControl_includes = data } )
                }
              ]
            ]
          ]
      ]

storeData : SectionKinds SampleData
storeData =
  Branch <| List
    { title = "Does your organization store data on behalf of VSP?"
    }
    [ Leaf <| BoolField
      { id = "storeData"
      , get = .storeData
      , set = (\ model data -> { model | storeData = data } )
      }
    , Branch <| Conditional
          { predicate = (\ model -> model.storeData)
          , hide = True
          }
          [ Branch <| List
            { title = "Does your organization store data on behalf of VSP?"
            }
            [ Leaf <| RadioField
                { id = "storeData_location"
                , options = Dict.fromList
                  [ ( "1_physical", "Physical" )
                  , ( "2_cloud", "Cloud" )
                  ]
                , get = .storeData_location
                , set = (\ model data -> { model | storeData_location = data } )
                }
            ]
          ]
    ]

physical : SectionKinds SampleData
physical =
  Branch <| Bullets
      { title = "PHYSICAL AND ENVIRONMENTAL PROTECTION"
      , type_ = NumericBullet
      , show = True
      }
      [ Branch <| Conditional
          { predicate = (\ model -> Set.member "1_physical" model.storeData_location)
          , hide = True
          }
          [ optionalInfoRisk
            { id = "physical_privateCloudOrDatacenter"
            , title = "Will your organization host VSP data in a private cloud, or datacenter environment?"
            , descriptionLabel = "Please provide the city and state of the datacenter(s) hosting VSP data."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .physical_privateCloudOrDatacenter
            , set = (\ model data -> { model | physical_privateCloudOrDatacenter = data } )
            }
            [ Branch <| Bullets
              { title = "Does your private cloud or datacenter include (check all that apply):"
              , type_ = NumericBullet
              , show = True
              }
              [ Leaf <| RadioField
                { id = "physical_privateCloudOrDatacenter_includes"
                , options = Dict.fromList
                  [ ( "1_multiFactorAuth", "Multi-factor authentication to access?" )
                  , ( "2_fireDetection", "Automated fire detection and supression mechanisms?" )
                  , ( "3_powerFeeds", "Multiple power feeds?" )
                  , ( "4_powerSupply", "Long-term emergency power supply?" )
                  , ( "5_humidityControls", "Temperature and humidity controls?" )
                  , ( "6_waterDamage", "Water damage protection?" )
                  ]
                , get = .physical_privateCloudOrDatacenter_includes
                , set = (\ model data -> { model | physical_privateCloudOrDatacenter_includes = data } )
                }
              ]
            ]

            , optionalInfoRisk
              { id = "physical_protectionPolicy"
              , title = "Does your organization have a formal Physical and Environmental Protection policy?"
              , descriptionLabel = "Provide further detail if necessary."
              , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
              , get = .physical_protectionPolicy
              , set = (\ model data -> { model | physical_protectionPolicy = data } )
              } []

            , optionalInfoRisk
              { id = "physical_securityVideo"
              , title = "Does your organization use CCTV cameras to record security video?"
              , descriptionLabel = "Provide further detail if necessary."
              , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
              , get = .physical_securityVideo
              , set = (\ model data -> { model | physical_securityVideo = data } )
              }
              [ optionalInfoRisk
                { id = "physical_securityVideo_kept60Days"
                , title = "Does your organization retain security video footage for at least sixty days?"
                , descriptionLabel = "Provide further detail if necessary."
                , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
                , get = .physical_securityVideo_kept60Days
                , set = (\ model data -> { model | physical_securityVideo_kept60Days = data } )
                } []
              ]

            , optionalInfoRisk
              { id = "physical_keyCard"
              , title = "Does your organization use a key card system to manage physical access to the facility handling VSP data?"
              , descriptionLabel = "Describe how key card access is authorized, provisioned, and removed."
              , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
              , get = .physical_keyCard
              , set = (\ model data -> { model | physical_keyCard = data } )
              } []
            
            , optionalInfoRisk
              { id = "physical_visitors"
              , title = "Does your organization allow visitors into facilities handling VSP data?"
              , descriptionLabel = "Describe how visitor access to facilities handling VSP data is restricted."
              , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
              , get = .physical_visitors
              , set = (\ model data -> { model | physical_visitors = data } )
              }
              [ optionalInfoRisk
                { id = "physical_visitors_badges"
                , title = "Are visitors required to wear a badge at all times?"
                , descriptionLabel = "Provide further detail if necessary."
                , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
                , get = .physical_visitors_badges
                , set = (\ model data -> { model | physical_visitors_badges = data } )
                } []

              , optionalInfoRisk
                { id = "physical_visitors_videoKept60Days"
                , title = "Does your organization retain security video footage for at least sixty days?"
                , descriptionLabel = "Provide further detail if necessary."
                , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
                , get = .physical_visitors_videoKept60Days
                , set = (\ model data -> { model | physical_visitors_videoKept60Days = data } )
                } []

              , optionalInfoRisk
                { id = "physical_visitors_escorted"
                , title = "Are visitors escorted by employees at all times?"
                , descriptionLabel = "Provide further detail if necessary."
                , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
                , get = .physical_visitors_escorted
                , set = (\ model data -> { model | physical_visitors_escorted = data } )
                } []

              , optionalInfoRisk
                { id = "physical_visitors_logsFor90Days"
                , title = "Is visitor access logged and kept for at least ninety days?"
                , descriptionLabel = "Provide further detail if necessary."
                , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
                , get = .physical_visitors_logsFor90Days
                , set = (\ model data -> { model | physical_visitors_logsFor90Days = data } )
                } []
              ]

            , optionalInfoRisk
              { id = "physical_physicalAccess"
              , title = "Does your organization monitor physical access to the facility handling VSP data?"
              , descriptionLabel = "Describe how your organization monitors physical access to your facilities."
              , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
              , get = .physical_physicalAccess
              , set = (\ model data -> { model | physical_physicalAccess = data } )
              }
              [ optionalInfoRisk
                { id = "physical_physicalAccess_reviewLogs"
                , title = "Does your organization review physical access logs regularly?"
                , descriptionLabel = "Provide further detail if necessary."
                , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
                , get = .physical_physicalAccess_reviewLogs
                , set = (\ model data -> { model | physical_physicalAccess_reviewLogs = data } )
                } []

              , optionalInfoRisk
                { id = "physical_physicalAccess_securityGuard"
                , title = "Does your organization employ security guards to monitor the facility?"
                , descriptionLabel = "Provide further detail if necessary."
                , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
                , get = .physical_physicalAccess_securityGuard
                , set = (\ model data -> { model | physical_physicalAccess_securityGuard = data } )
                } []
              ]

            , optionalInfoRisk
                { id = "physical_secureEquipmentTransfer"
                , title = "Does your organization have a process for secure delivery and removal of equipment into and out of the datacenter?"
                , descriptionLabel = "Describe how your organization controls the movement of equipment in and out of the datacenter."
                , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
                , get = .physical_secureEquipmentTransfer
                , set = (\ model data -> { model | physical_secureEquipmentTransfer = data } )
                } []

            , optionalInfoRisk
              { id = "physical_withinUSA"
              , title = "Will your organization only handle VSP data within the United States?"
              , descriptionLabel = "Provide further detail if necessary."
              , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
              , get = .physical_withinUSA
              , set = (\ model data -> { model | physical_withinUSA = data } )
              } []
          ]
      ]


media : SectionKinds SampleData
media =
  Branch <| Bullets
      { title = "MEDIA PROTECTION"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "media_markForHandling"
        , title = "Does your organization mark both digital and non-digital media containing VSP data to indicate appropriate handling?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .media_markForHandling
        , set = (\ model data -> { model | media_markForHandling = data } )
        } []

      , optionalInfoRisk
        { id = "media_physicalProtection"
        , title = "Does your organization physically protect the storage of both digital and non-digital media containing VSP data?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .media_physicalProtection
        , set = (\ model data -> { model | media_physicalProtection = data } )
        } []

      , optionalInfoRisk
        { id = "media_secureTransport"
        , title = "Does your organization transport both digital and non-digital media containing VSP data via secure means (locked containers, encryption, etc.)?"
        , descriptionLabel = "Provide further detail if necessary."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .media_secureTransport
        , set = (\ model data -> { model | media_secureTransport = data } )
        } []

      , optionalInfoRisk
        { id = "media_secureDesruction"
        , title = "Does your organization securely destroy media at end of life by shredding, degaussing, or wiping?"
        , descriptionLabel = "Describe how your organization securely destroys media."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .media_secureDesruction
        , set = (\ model data -> { model | media_secureDesruction = data } )
        } []
      ]


cloud : SectionKinds SampleData
cloud =
  Branch <| Bullets
      { title = "CLOUD STORAGE OPTIONS"
      , type_ = NumericBullet
      , show = True
      }
      [ Branch <| Conditional
          { predicate = (\ model -> Set.member "2_cloud" model.storeData_location)
          , hide = True
          }
          [ optionalInfoRisk
            { id = "cloud_storeData"
            , title = "Will your organization store VSP data in a public, shared, or hybrid cloud environment?"
            , descriptionLabel = "Describe how your organization monitors physical access to your facilities."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .cloud_storeData
            , set = (\ model data -> { model | cloud_storeData = data } )
            }
            [ Leaf <| InputField
                { id = "cloud_storeData_complianceReports"
                , label = "Please provide the cloud facility’s SSAE 16 SOC 1 or SOC 2 report covering the facilities handling VSP data."
                , placeholder = ""
                , error = False
                , get = .cloud_storeData_complianceReports
                , set = (\ model data -> { model | cloud_storeData_complianceReports = data } )
                }
            , Leaf <| InputField
                { id = "cloud_storeData_datacenterTier"
                , label = "Please indicate the datacenter tier the cloud facility is operating at."
                , placeholder = ""
                , error = False
                , get = .cloud_storeData_datacenterTier
                , set = (\ model data -> { model | cloud_storeData_datacenterTier = data } )
                }
            ]

          , optionalInfoRisk
            { id = "cloud_withinUSA"
            , title = "Will your organization only handle VSP data within the United States?"
            , descriptionLabel = "Provide further detail if necessary."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .cloud_withinUSA
            , set = (\ model data -> { model | cloud_withinUSA = data } )
            } []
          ]
      ]

security : SectionKinds SampleData
security =
  Branch <| Bullets
      { title = "SECURITY ASSESSMENT AND AUTHORIATION"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "security_regularAssements"
        , title = "Does your organization perform regular vulnerability assessments of the information systems used to process VSP data?"
        , descriptionLabel = "Describe how your organization performs vulnerability assessments of its information systems, including methods and tools used."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .security_regularAssements
        , set = (\ model data -> { model | security_regularAssements = data } )
        }
        [ optionalInfoRisk
            { id = "security_regularAssements_remediation"
            , title = "Does your organization remediate  ndings within de ned timeframes based on the  nding’s risk?"
            , descriptionLabel = "Describe your SLAs for remediating vulnerability assessment  ndings."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .security_regularAssements_remediation
            , set = (\ model data -> { model | security_regularAssements_remediation = data } )
            } []

        ]

      , optionalInfoRisk
        { id = "security_regularPenetration"
        , title = "Does your organization perform regular penetration testing of the information systems used to process VSP data?"
        , descriptionLabel = "Describe how your organization performs penetration testing of its information systems, including methods and tools used."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .security_regularPenetration
        , set = (\ model data -> { model | security_regularPenetration = data } )
        } []

      , optionalInfoRisk
        { id = "security_continuouslyMonitor"
        , title = "Does your organization continuously monitor information systems for continued compliance?"
        , descriptionLabel = "Describe how your organization performs such monitoring."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .security_continuouslyMonitor
        , set = (\ model data -> { model | security_continuouslyMonitor = data } )
        } []
      ]

contingency : SectionKinds SampleData
contingency =
  Branch <| Bullets
      { title = "CONTINGENCY PLANNING"
      , type_ = NumericBullet
      , show = True
      }
      [ optionalInfoRisk
        { id = "contingency_regularBackups"
        , title = "Does your organization perform regular backups of information systems handling VSP data?"
        , descriptionLabel = "Describe your information backup process as it pertains to systems handling VSP data."
        , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        , get = .contingency_regularBackups
        , set = (\ model data -> { model | contingency_regularBackups = data } )
        }
        [ optionalInfoRisk
            { id = "contingency_regularBackups_testMedia"
            , title = "Does your organization regularly test backup media to ensure functionality?"
            , descriptionLabel = "Provide further detail if necessary."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .contingency_regularBackups_testMedia
            , set = (\ model data -> { model | contingency_regularBackups_testMedia = data } )
            } []

        , optionalInfoRisk
            { id = "contingency_regularBackups_storeOffsite"
            , title = "Does your organization store backup media offsite?"
            , descriptionLabel = "Provide city and state of the backup media’s location(s)."
            , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            , get = .contingency_regularBackups_storeOffsite
            , set = (\ model data -> { model | contingency_regularBackups_storeOffsite = data } )
            } []
        ]

      , optionalInfoRisk
          { id = "contingency_disasterRecovery"
          , title = "Does your organization have a formal Disaster Recovery Plan that is periodically reviewed, updated, and approved by management?"
          , descriptionLabel = "Describe your organization’s disaster recovery strategy."
          , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
          , get = .contingency_disasterRecovery
          , set = (\ model data -> { model | contingency_disasterRecovery = data } )
          }
          [ optionalInfoRisk
              { id = "contingency_disasterRecovery_annualExcercise"
              , title = "Does your organization perform at least annual disaster recovery exercises?"
              , descriptionLabel = "Provide further detail if necessary."
              , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
              , get = .contingency_disasterRecovery_annualExcercise
              , set = (\ model data -> { model | contingency_disasterRecovery_annualExcercise = data } )
              } []
          ]

      , optionalInfoRisk
          { id = "contingency_continuityPlan"
          , title = "Does your organization have a formal Business Continuity Plan that is periodically reviewed, updated, and approved by management?"
          , descriptionLabel = "Describe your organization’s business continuity strategy."
          , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
          , get = .contingency_continuityPlan
          , set = (\ model data -> { model | contingency_continuityPlan = data } )
          }
          [ optionalInfoRisk
              { id = "contingency_continuityPlan_annualExcercise"
              , title = "Does your organization perform at least annual business continuity testing?"
              , descriptionLabel = "Provide further detail if necessary."
              , riskLabel = "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
              , get = .contingency_continuityPlan_annualExcercise
              , set = (\ model data -> { model | contingency_continuityPlan_annualExcercise = data } )
              } []
          ]

      ]