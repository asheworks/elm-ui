module Example.InfoSec exposing (..)

import Example.FormBuilder exposing (..)


type alias Meta =
  { visible : Bool
  }


infoSection :
  String ->
  String ->
  String ->
  String ->
  (List ( Sections ContainerFacts (DataFacts Meta) Meta ) ) ->
  Sections ContainerFacts (DataFacts Meta) Meta
infoSection key title descriptionLabel riskLabel children =
  section key []
    ( BulletList NumericBullets title ) <|

    [ field "selected" [] <|

        Bool
          [ default False
          ]
          ( YesNo )
          

    , field "description"
        [ visible (byId <| key ++ ".selected") <| boolIs True
        ] <|

        Text []
          ( TextInput descriptionLabel [] )

    , field "risk"
        [ visible (byId <| key ++ ".selected") <| boolIs False
        ] <|

        Text []
          ( TextInput riskLabel [] )

    ] ++ children


infosec : Sections ContainerFacts (DataFacts Meta) Meta
infosec =
  section "infosec" []
    ( Header "InfoSec Questionnaire" )

    [ field "version" [] <|

        Text
          [ default "v1.0.0"
          ]
          ( TextLabel "Version" )

    , details
    -- , definitions
    -- , serviceDescription
    -- , documentation
    -- , awarenessAndTraining
    ]


details : Sections ContainerFacts (DataFacts Meta) Meta
details =
  section "details" []
    ( Grid )

    [ field "companyName" [] <|

        Text []
          ( TextInput "Company Name" [] )
    
    , field "contactName" [] <|

        Text []
          ( TextInput "Contact Name" [] )

    , field "emailAddress" [] <|

        Text []
          ( TextInput "Email Address"
              [ placeholder "user@email.com"
              ]
          )
      
    , field "date" [] <|

        Text []
          ( TextInput "Date"
              [ placeholder "mm-dd-yyyy"
              ]
          )

    , field "title" [] <|

        Text []
          ( TextInput "Title" [] )

    , field "telephone" [] <|

        Text []
          ( TextInput "Telephone"
            [ placeholder "(xxx) xxx-xxxx"
            ]
          )
    ]


definitions : Sections ContainerFacts (DataFacts Meta) Meta
definitions =
  section "definitions" []
    ( List "Dfinitions:" )

    [ field "infoSys" [] <| 
        Text
          [ default "Those information systems used by Contractor to collect, process, maintain, use, share, disseminate, or disposition VSP data."
          ]
          ( TextLabel "Information System" )

    , field "vspData" [] <|
        Text
          [ default "Information provided to Contractor by or at the direction of VSP that: (i) identi es an individual (including, without limitation, names, signatures, addresses, telephone numbers, e-mail addresses and other unique identi ers); or (ii) can be used to authenticate an individual(including, without limitation, employee identi cation numbers, government- issued identi cation numbers, passwords or PINs, biometric or health data, answers to security questions and other personal identi ers)."
          ]
          ( TextLabel "VSP Data" )

    ]


serviceDescription : Sections ContainerFacts (DataFacts Meta) Meta
serviceDescription =
  section "services" []
    ( BulletList AlphaBullets
        "Service Description:"
    )

    [ section "" []
        ( BulletList NumericBullets
            "Check all boxes which best describe the service(s) you will be offering VSP."
        )

        [ field "selected" [] <|
            ( Option []
              [ ( "saas", "SaaS" )
              , ( "iaas", "IaaS" )
              , ( "talent", "Talent / Labor" )
              , ( "other", "Other" )
              ]
              ( Checkbox "" )
            )

        , field "description" [] <|
            Text []
              ( TextInput "Please describe services offered" [] )

        , section "compliance" []
            ( BulletList NumericBullets
                "Check all boxes which describe the type of data you will be handling on behalf of VSP."
            )
            [ field "selected" [] <|
                ( Option []
                  [ ( "pii", "PII" )
                  , ( "phi", "PHI" )
                  , ( "pci", "PCI" )
                  , ( "conf", "Business Confidential" )
                  ]
                  ( Checkbox "" )
                )

            , section "" []
                ( BulletList NumericBullets
                    "Does your organization comply with Massachusetts 201 CMR 17.00?"
                )
                [ field "pii" [] <|
                    ( Bool [] YesNoMaybe )
                ]

            , section "" []
                ( BulletList NumericBullets
                    "Does your organization comply with the HIPAA & HITECH rules?"
                )
                [ field "phi" [] <|
                    ( Bool [] YesNoMaybe )
                ]

            , section "" []
                ( BulletList NumericBullets
                    "Does your organization comply with thePayment Card Industry Data Security Standards?"
                )
                [ field "pci" [] <|
                    ( Bool [] YesNoMaybe )
                ]
            ]
        ]
    ]


documentation : Sections ContainerFacts (DataFacts Meta) Meta
documentation =
  section "documentation" []
    ( BulletList NumericBullets
        "Supporting Documentation:"
    )

    [ field "thirdParty" [] <|
        ( Bool [] YesNoMaybe )

    , field "files" [] <|
        ( FileUpload [] MutiUpload )
    ]


awarenessAndTraining : Sections ContainerFacts (DataFacts Meta) Meta
awarenessAndTraining =
  section "awareness" []
    ( BulletList NumericBullets
        "AWARENESS AND TRAINING"
    )

    [ infoSection
        "periodicallyReviewed"
        "Does your organization have a formal security awareness policy that is periodically reviewed, updated, and approved by management?"
        "Provide further detail if necessary"
        "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
        []

    , infoSection
        "requiredParticipation"
        "Does your organization have a security awareness training program that requires annual participation by all personnel?"
        "Describe how your organization provides appropriate information security training to personnel."
        "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."

        [ infoSection
            "roleTraining"
            "Does your security awareness training program use role-based training?"
            "Provide further detail if necessary"
            "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            []

        , infoSection
            "compliance"
            "Does your organization track security awareness training completion by personnel to ensure compliance?"
            "Provide further detail if necessary"
            "Warning: Possible Risk If there are legitimate reasons for your answer, please explain below."
            []

        ]
    ]
