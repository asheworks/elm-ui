module Example.FormBuilder2 exposing
  ( SectionTypes(..)
  , dataTree
  , questionnaire
  )


import Dict exposing (..)
import Html exposing (..)
import MultiwayTree exposing (..)
import MultiwayTreeZipper exposing (..)
import Set exposing (..)

--


keepJusts : List (Maybe a) -> List a
keepJusts list = 
  case list of 
    [] ->
      []
    mx :: xs ->
      case mx of 
        Nothing ->
          keepJusts xs
          
        Just x ->
          x :: keepJusts xs


type alias Id = String


type alias Title = String


type alias Placeholder = Maybe String


type alias Hidden = Bool


hidden : Bool
hidden = True


visible : Bool
visible = False


noPlaceholder : Maybe String
noPlaceholder = Nothing


placeholder : String -> Maybe String
placeholder value = Just value


asTextNode : Zipper (SectionTypes aspects) -> Maybe (Id, TextTypes, String)
asTextNode ((tree, _) as zipper) =
  case tree of
    Tree node _ ->
      case node of
        Text id type_ value _ -> Just (id, type_, value)

        _ -> Nothing


type SectionTypes aspects
  = Field Id NodeTypes (List aspects) (List (SectionTypes aspects))

  | Bool Id BoolTypes Bool  (List aspects)
  | Options Id OptionTypes (List (String, String)) (List aspects)
  | Text Id TextTypes String (List aspects)


type NodeTypes
  = Header Title
  | Grid Title
  | List Title
  | BulletList Title BulletTypes Hidden


type DataTypes
  = BoolData Bool
  | OptionsData (Set String)
  | TextData String


-- type DataTypes
--   = Field Id (List DataTypes)

--   | Bool Id Bool
--   | Options Id (Set String)
--   | Text Id String


type Metas aspects
  = Validation Navigations (Zipper (SectionTypes aspects) -> Maybe String)
  | Conditional Navigations (Zipper (SectionTypes aspects) -> Bool)


type Navigations
  = Current
  | NodeByPath String





type BulletTypes
  = AlphaBullets
  | NumericBullets


type BoolTypes
  = YesNo Title


type OptionTypes
  = Checkbox Title (List String)
  | Radio Title String


type TextTypes
  = InputField Title Placeholder
  | LabeledText Title


type Command
  = BoolField_Update String Bool
  | InputField_Update String String
  | RadioField_Update String (Int, String)


type Event
  = BoolField_Updated String Bool
  | InputField_Updated String String
  | RadioField_Updated String (Int, String)


type Effect
  = None


buildForm : Html Command
buildForm =
  div [][]


-- type alias Section aspects =
--   { section : Zipper (SectionTypes aspects)
--   , ui : Maybe (Zipper UITypes)
--   , data : Maybe (Zipper DataTypes)
--   }


-- asTree : SectionTypes aspects -> Tree (SectionTypes aspects)
-- asTree node =
--   case node of
--     Field _ _ _ children ->
--       children
--         |> List.map (\ child -> asTree child )
--         |> Tree node
  
--     _ -> Tree node []


-- asTree : SectionTypes aspects -> Tree (SectionTypes aspects)
-- asTree node =
--   case node of
--     Field _ _ _ children ->
--       let
--         c : List (SectionTypes aspects) -> List (SectionTypes aspects)
--         c = children
--               |> List.map (\ c -> c )
--       in
--         Tree node []

--       -- children
--       --   |> List.map asTree
--       --   |> Tree node
  
--     _ -> Tree node []


asTree : SectionTypes aspects -> Tree (SectionTypes aspects)
asTree node =
  Tree node []


asData : SectionTypes aspects -> (String, Maybe DataTypes)
asData node =
  case node of
    Field id type_ aspects children ->
      ( id, Nothing )

    Bool id type_ default aspects ->
      ( id, Just <| BoolData default )
    
    Options id type_ default aspects ->
      ( id, 
        Just
          <| OptionsData
          <| Set.fromList
          <| List.map (\ (key, _) -> key ) default
      )
      
    Text id type_ default aspects ->
      ( id, Just <| TextData default )


getId : SectionTypes aspects -> String
getId node =
  case node of
    Field id _ _ _ -> id
    Bool id _ _ _ -> id
    Options id _ _ _ -> id
    Text id _ _ _ -> id


withId : SectionTypes aspects -> Maybe (SectionTypes aspects)
withId node =
  if getId node == "" then
    Nothing
  else
    Just node

withoutId : SectionTypes aspects -> Maybe (SectionTypes aspects)
withoutId node =
  if getId node == "" then
    Just node
  else
    Nothing

dataChildren : SectionTypes aspects -> List (SectionTypes aspects)
dataChildren node =
  case node of
    Field id _ _ children ->
      let
        children_ =
          children
            |> List.filterMap withId

        -- t = Debug.log "withid" children_

        empties =
          children
            |> List.filterMap withoutId
            |> List.concatMap dataChildren
      in
        empties ++ children_
        

    _ -> []


dataTree : SectionTypes aspects -> Tree (String, Maybe DataTypes)
dataTree node =
  node
  |> dataChildren
  |> List.map dataTree
  |> Tree (asData node)

  -- case node of
    
  --   Field _ _ _ _ ->
  --     dataChildren node
  --       |> List.map dataTree
  --       |> Tree (asData node)

  --   _ ->
  --     Tree (asData node) []


-- dataTree : SectionTypes aspects -> Tree (String, Maybe DataTypes)
-- dataTree node =
--   case asData node of
--     Just data ->
--       case node of

--         Field _ _ _ children ->
--           children
--             |> List.map dataTree
--             |> Tree data

--         _ ->
--           Tree data []

--     Nothing ->
--       let
--         subs = case node of
--           Field _ _ _ children ->

--           _ -> Nothing
--         t = Debug.log "" ""
--       in
--         Tree ("empty", Nothing) []


dataTreeMap : SectionTypes aspects -> Tree (String, Maybe DataTypes)
dataTreeMap node =
  case node of

    Field _ _ _ children ->
      children
        |> List.map dataTreeMap
        |> Tree (asData node)

    _ ->
      Tree (asData node) []

  -- case asData node of

  --   Nothing ->

  --     Tree ("", Nothing) []

  --   Just data ->

  --     Tree ("", Nothing) []

    -- zipper node

-- children
            --   |> List.map dataTree
            --   |> (id, Nothing)

 -- let
            --   c = children
            --         |> List. .concatMap dataTree
            --         -- |> List.concatMap dataTree

            --   t = Debug.log "dataTree" c
            -- in

-- children
            -- |> List.map dataTree
            -- |> List.concatMap dataTree
            -- |> List.map
            --   (\ tree ->
            --     case tree of
            --       Tree (id, data) _ -> (id, data))

          -- children
          --   |> List.map dataTree
            
          -- |> Tree (parent)


questionnaire : SectionTypes aspects
questionnaire =
  Field "infosec"
    ( Header "Information Security Questionnaire" )
    []
    -- [ contractorInformation
    -- , definitions
    -- , serviceDetails
    -- ]
    [ Field "" ( Grid "" ) []
        [ Field "" ( Grid "" ) [] []
        , Field "" ( Grid "" ) []
            [ Field "a" ( Grid "" ) [] []
            , Field "b" ( Grid "" ) [] []
            , Field "c" ( Grid "" ) [] []
            ]
        , Field "d" ( Grid "" ) [] []
        , Field "e" ( Grid "" ) [] []
        ]
    ]


contractorInformation : SectionTypes aspects
contractorInformation =
  Field "contractorInfo"
    ( Grid "Contractor Information" )
    []
    [ Text "companyName"
        ( InputField "Company Name" noPlaceholder )
        ""
        []
        -- [ Validation Current
        --     (\ zipper ->
        --       case asTextNode zipper  of
        --         Nothing -> Just "Invalid binding"

        --         Just (_, value, _) ->
        --           if value == "" then
        --             Just "Required"
        --           else
        --             Nothing
        --     )
        -- ]

    , Text "contactName"
        ( InputField "Contact Name" noPlaceholder )
        ""
        []

    , Text "emailAddress"
        ( InputField "Email Address" <| placeholder "user@email.com" )
        ""
        []

    , Text "date"
        ( InputField "Date" <| placeholder "mm-dd-yyyy" )
        ""
        []

    , Text "title"
        ( InputField "Title" noPlaceholder )
        ""
        []

    , Text "telephone"
        ( InputField "Telephone" <| placeholder "(xxx) xxx-xxxx" )
        ""
        []

    ]


definitions : SectionTypes aspects
definitions =
  Field "definitions"
    ( List "Definitions" )
    []

    [ Text "informationSystems"
        ( LabeledText "Information Systems" )
        "Those information systems used by Contractor to collect, process, maintain, use, share, disseminate, or disposition VSP data."
        []
    
    , Text "vspData"
        ( LabeledText "VSP Data" )
        "Information provided to Contractor by or at the direction of VSP that: (i) identi es an individual (including, without limitation, names, signatures, addresses, telephone numbers, e-mail addresses and other unique identi ers); or (ii) can be used to authenticate an individual (including without limitation, employee identi cation numbers, government- issued identi cation numbers, passwords or PINs, biometric or health data, answers to security questions and other personal identi ers)."
        []
    ]


serviceDetails : SectionTypes aspects
serviceDetails =
  Field "serviceDetails"
    ( BulletList "Service Description"
        AlphaBullets
        hidden
    )
    []

    [ Field "services"
        ( BulletList "Check all boxes which best describe the service(s) you will be offering VSP."
            NumericBullets
            visible
        )
        []

        [ Options "offered"
            ( Checkbox "" [] )
            [ ( "saas", "SaaS" )
            , ( "iaas", "IaaS" )
            , ( "talent", "Talent / Labor" )
            , ( "other", "Other" )
            ]            
            []

        , Text "description"
            ( InputField "Please describe services offered" noPlaceholder )
            ""
            []
        ]

    , Field "dataTypes"
        ( BulletList "Check all boxes which describe the type of data you will be handling on behalf of VSP."
            NumericBullets
            visible
        )
        []

        [ Options "applicable"
            ( Checkbox "" [] )
            [ ( "pii", "PII" )
            , ( "phi", "PHI" )
            , ( "pci", "PCI" )
            , ( "conf", "Business Confidential" )
            ]
            []

        , Field "pii"
            ( BulletList "Does your organization comply with Massachusetts 201 CMR 17.00?"
                NumericBullets
                visible
            )
            []

            [ Bool "compliance"
                ( YesNo "" )
                False
                []
                -- [ Conditional (NodeByPath "*.dataTypes.applicable")
                --     (\ node -> False )
                -- ]
            ]

        , Field "phi"
            ( BulletList "Does your organization comply with the HIPAA & HITECH rules?"
                NumericBullets
                visible
            )
            []

            [ Bool "compliance"
                ( YesNo "" )
                False
                []
                -- [ Conditional (NodeByPath "*.dataTypes.applicable")
                --     (\ node -> False )
                -- ]
            ]

        , Field "pci"
            ( BulletList "Does your organization comply with thePayment Card Industry Data Security Standards?"
                NumericBullets
                visible
            )
            []

            [ Bool "compliance"
                ( YesNo "" )
                False
                []
                -- [ Conditional (NodeByPath "*.dataTypes.applicable")
                --     (\ node -> False )
                -- ]
            ]
        ]
    ]
